package schoolobjects.animals;


public interface Animal {

	public String getSound();
	public String getType();
}
