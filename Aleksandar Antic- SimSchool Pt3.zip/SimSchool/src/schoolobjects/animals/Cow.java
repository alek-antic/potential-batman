package schoolobjects.animals;

import gpdraw.DrawingTool;
import schoolobjects.LivingThing;

public class Cow extends LivingThing implements Animal {
	private String myType;
	private String mySound;

	Cow() {
		myType = "cow";
		mySound = "moo";
	}

	public String getSound() {
		return mySound;
	}

	public String getType() {
		return myType;
	}

	public String toString() {
		return "The " + getType() + " goes " + getSound();
	}

	@Override
	public void draw(DrawingTool marker, int x, int y) {
		super.draw(marker, x, y);
	}

}
