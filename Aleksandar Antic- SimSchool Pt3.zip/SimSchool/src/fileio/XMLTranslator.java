package fileio;

import java.util.ArrayList;

import javax.xml.parsers.*;

import schoolobjects.people.*;

import org.w3c.dom.*;

import java.io.*;

public class XMLTranslator {

	private ArrayList<Person> people;
	private ArrayList<Teacher> teachers;
	private ArrayList<Student> students;
	private ArrayList<CollegeStudent> collegeStudents;
	
	public XMLTranslator() {
		people = new ArrayList<Person>();
		teachers = new ArrayList<Teacher>();
		students = new ArrayList<Student>();
		collegeStudents = new ArrayList<CollegeStudent>();
	}

	public void readXML(String filename) {
		try {
			File xml = new File(filename);
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();

			Document document = builder.parse(xml);

			document.getDocumentElement().normalize();

			NodeList persons = document.getElementsByTagName("Person");
			NodeList teacher = document.getElementsByTagName("Teacher");
			NodeList student = document.getElementsByTagName("Student");
			NodeList collegeStudent = document.getElementsByTagName("CollegeStudent");

			for (int i = 0; i < persons.getLength(); i++) {
				Node nNode = persons.item(i);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element e = (Element) nNode;

					String name = e.getElementsByTagName("name").item(0).getTextContent();
					int age = Integer.parseInt(e.getElementsByTagName("age").item(0).getTextContent());
					String gender = e.getElementsByTagName("gender").item(0).getTextContent();
					Person p = new Person(name, age, gender);
					people.add(p);
				}
			}

			for (int i = 0; i < teacher.getLength(); i++) {
				Node nNode = teacher.item(i);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element e = (Element) nNode;

					String name = e.getElementsByTagName("name").item(0).getTextContent();
					int age = Integer.parseInt(e.getElementsByTagName("age").item(0).getTextContent());
					String gender = e.getElementsByTagName("gender").item(0).getTextContent();
					String subject = e.getElementsByTagName("subject").item(0).getTextContent();
					double salary = Double.parseDouble(e.getElementsByTagName("salary").item(0).getTextContent());
					Teacher p = new Teacher(name, age, gender,subject,salary);
					teachers.add(p);
				}
			}
			
			for(int i = 0; i < student.getLength(); i++) {
				Node nNode = student.item(i);
				
				if(nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element e = (Element)nNode;
					
					String name = e.getElementsByTagName("name").item(0).getTextContent();
					int age = Integer.parseInt(e.getElementsByTagName("age").item(0).getTextContent());
					String gender = e.getElementsByTagName("gender").item(0).getTextContent();
					String ID = e.getElementsByTagName("ID").item(0).getTextContent();
					double GPA = Double.parseDouble(e.getElementsByTagName("GPA").item(0).getTextContent());
					Student p = new Student(name,age,gender,ID,GPA);
					students.add(p);
				}
			}
			
			for(int i = 0; i < collegeStudent.getLength(); i++) {
				Node nNode = collegeStudent.item(i);
				
				if(nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element e = (Element)nNode;
					
					String name = e.getElementsByTagName("name").item(0).getTextContent();
					int age = Integer.parseInt(e.getElementsByTagName("age").item(0).getTextContent());
					String gender = e.getElementsByTagName("gender").item(0).getTextContent();
					String ID = e.getElementsByTagName("ID").item(0).getTextContent();
					double GPA = Double.parseDouble(e.getElementsByTagName("GPA").item(0).getTextContent());
					int year = Integer.parseInt(e.getElementsByTagName("year").item(0).getTextContent());
					String major = e.getElementsByTagName("major").item(0).getTextContent();
					CollegeStudent p = new CollegeStudent(name,age,gender,ID,GPA,year,major);
					collegeStudents.add(p);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ArrayList<Person> getPeople() {
		return people;
	}
	
	public ArrayList<Teacher> getTeachers() {
		return teachers;
	}
	
	public ArrayList<Student> getStudents() {
		return students;
	}
	
	public ArrayList<CollegeStudent> getCollegeStudents() {
		return collegeStudents;
	}
}
