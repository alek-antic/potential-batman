package gui;

import java.util.ArrayList;

import schoolobjects.animals.Pig;
import schoolobjects.people.CollegeStudent;
import schoolobjects.people.Person;
import schoolobjects.people.Student;
import schoolobjects.people.Teacher;
import fileio.XMLTranslator;
import gpdraw.*;


public class SimSchool {

	
	public static void main(String[] args) {
		Person bob = new Person("Coach Bob", 27, "M");
		System.out.println(bob);

		Student lynne = new Student("Lynne Brooke", 16, "F", "HS95129", 3.5);
		System.out.println(lynne);

		Teacher mrJava = new Teacher("Duke Java", 34, "M", "Computer Science", 50000);
		System.out.println(mrJava);

		CollegeStudent ima = new CollegeStudent("Ima Frosh", 18, "F", "UCB123",
		                                         4.0, 1, "English");
		System.out.println(ima);
		
		XMLTranslator trans = new XMLTranslator();
		
		trans.readXML("data/peopleXML.xml");
		
		ArrayList<Person> people = trans.getPeople();
		
		Pig pig = new Pig();
		
		SketchPad pad = new SketchPad(500,500);
		DrawingTool marker = new DrawingTool(pad);
		pig.draw(marker,0,0);
		
		

	}
}
